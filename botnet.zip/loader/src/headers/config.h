#pragma once

#define HTTP_SERVER "178.218.221.25"
#define HTTP_PORT 80

#define TFTP_SERVER "178.218.221.25"
